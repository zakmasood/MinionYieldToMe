Author = "--Dcybroz--"
import csv


####### Function definitions#######

#######
# Function to check minion strength
####
def MinionStrengthCalc(Tier, Fuel, Speed):
    with open('MinionFuel.csv') as f:
        reader = csv.reader(f)
        data = list(reader)
    result = [minion for minion in data if data[0][0] == Fuel]
    if result == []:  # or if not result
        return "No record found"
    else:
        return (result[0])


#######
def checkminion(MinionTypeInput):
    ValidMinionTypes = ['cobblestone', 'redstone', 'snow', 'spider', 'diamond', 'coal', 'gold', 'iron', 'lapis',
                        'emerald', 'slime', 'magma', 'enderman', 'skeleton', 'mithril', 'obsidian'
        , 'zombie', 'tarantula']
    for MinionType in ValidMinionTypes:
        if MinionType.lower() == MinionTypeInput.lower():
            return True
    return False


###############################################################
# Main program
print(MinionStrengthCalc(1, "Solar Panel", 3))

RomanInts = ["I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X", "XI", "XII"]
MaxMinionTier = 12

while True:
    MinionTypeInput = input("Enter MinionType here: ")
    TierInput = int(input("Enter tier here: "))
    HasFuel = input("Enter has fuel Y/N: ")
    if len(MinionTypeInput) == 0:
        print("Shutting down")
        break

    if checkminion(MinionTypeInput) == True:
        f = open("MinionTypes.txt", "a")
        f.write(str(MinionTypeInput) + " - Tier: " + str(RomanInts[TierInput - 1]) + str(HasFuel) + "\n")
        f.close()
        print(str(MinionTypeInput) + " " + str(RomanInts[TierInput - 1]))
